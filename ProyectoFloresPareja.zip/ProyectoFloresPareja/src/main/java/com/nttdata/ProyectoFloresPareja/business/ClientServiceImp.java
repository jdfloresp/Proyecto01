package com.nttdata.ProyectoFloresPareja.business;


import com.nttdata.ProyectoFloresPareja.model.ClienteRequest;
import com.nttdata.ProyectoFloresPareja.model.ClienteResponse;
import com.nttdata.ProyectoFloresPareja.model.entity.Client;
import com.nttdata.ProyectoFloresPareja.repository.ClientRepository;
import jakarta.persistence.Id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClientServiceImp implements ClientService {
    @Autowired
    ClientRepository clientRepository;

    @Autowired
    ClientMapper clientMapper;

    @Override
    public List<ClienteResponse> listClientes() {
        return clientRepository.findAll().stream()
                .map(m->clientMapper.getClienteResponse(m))
                .collect(Collectors.toList());
    }

    @Override
    public ClienteResponse registerCliente(ClienteRequest clienteRequest) {
        return clientMapper
                .getClienteResponse(clientRepository.save(clientMapper.getClienteEntity(clienteRequest)));
    }

   // @GetMapping(path = "/{id}")
    public Optional<Client> getClientebyId(Integer id){
    return clientRepository.findById(id);
    }


    public void deleteByid(Integer id){
        clientRepository.deleteById(id);
    }


}
