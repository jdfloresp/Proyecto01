package com.nttdata.ProyectoFloresPareja.business;


import com.nttdata.ProyectoFloresPareja.model.CuentaRequest;
import com.nttdata.ProyectoFloresPareja.model.CuentaResponse;
import com.nttdata.ProyectoFloresPareja.repository.CuentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CuentServiceImp implements CuentService{

    @Autowired
    CuentaRepository cuentaRepository;

    @Autowired
    CuentMapper cuentMapper;

    @Override
    public List<CuentaResponse> listCuentas() {
        return cuentaRepository.findAll().stream()
                .map(m->cuentMapper.getCuentaResponse(m))
                .collect(Collectors.toList());
    }

    @Override
    public CuentaResponse registerCuenta(CuentaRequest cuentaRequest) {
        return cuentMapper
                .getCuentaResponse(cuentaRepository.save(cuentMapper.getCuentaEntity(cuentaRequest)));
    }


}
