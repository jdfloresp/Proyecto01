package com.nttdata.ProyectoFloresPareja.repository;


import com.nttdata.ProyectoFloresPareja.api.CuentaApiDelegate;
import com.nttdata.ProyectoFloresPareja.business.CuentService;
import com.nttdata.ProyectoFloresPareja.model.CuentaRequest;
import com.nttdata.ProyectoFloresPareja.model.CuentaResponse;
import com.nttdata.ProyectoFloresPareja.model.entity.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.List;
import java.util.Optional;

@Component
public class CuentApiDelegateImp implements CuentaApiDelegate {

    @Autowired
    CuentService cuentService;

    @Override
    public ResponseEntity<List<CuentaResponse>> listCuentas() {
        return ResponseEntity.ok(cuentService.listCuentas());
    }

    @Override
    public ResponseEntity<CuentaResponse> registerCuenta(CuentaRequest cuentaRequest) {
        return ResponseEntity.ok(cuentService.registerCuenta(cuentaRequest));
    }


}
