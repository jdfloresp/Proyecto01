package com.nttdata.ProyectoFloresPareja.business;

import com.nttdata.ProyectoFloresPareja.model.CuentaRequest;
import com.nttdata.ProyectoFloresPareja.model.CuentaResponse;
import com.nttdata.ProyectoFloresPareja.model.entity.Client;

import java.util.List;
import java.util.Optional;
public interface CuentService {

    List<CuentaResponse> listCuentas();

    CuentaResponse registerCuenta(CuentaRequest cuentaRequest);


}
