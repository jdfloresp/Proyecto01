package com.nttdata.ProyectoFloresPareja.business;


import com.nttdata.ProyectoFloresPareja.model.ClienteRequest;
import com.nttdata.ProyectoFloresPareja.model.ClienteResponse;
import com.nttdata.ProyectoFloresPareja.model.entity.Client;
import jakarta.persistence.Id;

import java.util.List;
import java.util.Optional;

public interface ClientService {

 public List<ClienteResponse> listClientes();

public ClienteResponse registerCliente(ClienteRequest clienteRequest) ;


}
