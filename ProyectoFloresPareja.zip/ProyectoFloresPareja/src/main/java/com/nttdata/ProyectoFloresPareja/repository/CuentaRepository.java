package com.nttdata.ProyectoFloresPareja.repository;

import com.nttdata.ProyectoFloresPareja.model.entity.Cuent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CuentaRepository extends JpaRepository<Cuent,String> {
}
