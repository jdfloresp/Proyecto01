package com.nttdata.ProyectoFloresPareja.business;


import com.nttdata.ProyectoFloresPareja.model.ClienteRequest;
import com.nttdata.ProyectoFloresPareja.model.ClienteResponse;
import com.nttdata.ProyectoFloresPareja.model.entity.Client;
import org.springframework.stereotype.Component;

@Component
public class ClientMapper {


    //registrar cliente
    public Client getClienteEntity(ClienteRequest request){
        Client entity = new Client();
        entity.setNombres(request.getNombres());
        entity.setApellidos(request.getApellidos());
        entity.setDni(request.getDni());
        entity.setEmail(request.getEmail());
        return entity;
    }



    //listar clientes
    public ClienteResponse getClienteResponse(Client entity){
        ClienteResponse response = new ClienteResponse();
       // response.setClienteid(entity.getClienteid());
        response.setNombres(entity.getNombres());
        response.setApellidos(entity.getApellidos());
        response.setDni(entity.getDni());
        response.setEmail(entity.getEmail());
        return response;
    }


}
