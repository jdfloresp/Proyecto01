package com.nttdata.ProyectoFloresPareja.model.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name="cliente")

public class Client{
    @Id
    private String Nombres;
    private String Apellidos;
    private String dni;
    private String email;
}
