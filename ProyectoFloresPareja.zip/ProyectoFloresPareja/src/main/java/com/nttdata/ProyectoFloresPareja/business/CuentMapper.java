package com.nttdata.ProyectoFloresPareja.business;


import com.nttdata.ProyectoFloresPareja.model.ClienteRequest;
import com.nttdata.ProyectoFloresPareja.model.ClienteResponse;
import com.nttdata.ProyectoFloresPareja.model.CuentaRequest;
import com.nttdata.ProyectoFloresPareja.model.CuentaResponse;
import com.nttdata.ProyectoFloresPareja.model.entity.Client;
import com.nttdata.ProyectoFloresPareja.model.entity.Cuent;
import org.springframework.stereotype.Component;

@Component
public class CuentMapper {

    //registrar cuenta
    public Cuent getCuentaEntity(CuentaRequest request){
        Cuent entity = new Cuent();
        entity.setDatoscliente(request.getDatosCliente());
        entity.setNumcuenta(request.getNumCuenta());
        entity.setSaldo(request.getSaldo());
        entity.setTipocuenta(request.getTipoCuenta());
        return entity;
    }


    //listar cuentas
    public CuentaResponse getCuentaResponse(Cuent entity){
        CuentaResponse response = new CuentaResponse();
        response.setDatosCliente(entity.getDatoscliente());
        response.setNumCuenta(entity.getNumcuenta());
        response.setSaldo(entity.getSaldo());
        response.setTipoCuenta(entity.getTipocuenta());
        return response;
    }

}
