package com.nttdata.ProyectoFloresPareja.model.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@Table(name="cuentabancaria")
public class Cuent{
    @Id
    private String datoscliente;
    private String numcuenta;
    private String saldo;
    private String tipocuenta;
}
