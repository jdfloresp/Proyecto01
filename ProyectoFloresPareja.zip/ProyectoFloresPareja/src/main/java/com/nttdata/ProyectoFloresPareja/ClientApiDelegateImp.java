package com.nttdata.ProyectoFloresPareja;


import com.nttdata.ProyectoFloresPareja.api.ClienteApiDelegate;
import com.nttdata.ProyectoFloresPareja.business.ClientService;
import com.nttdata.ProyectoFloresPareja.model.ClienteRequest;
import com.nttdata.ProyectoFloresPareja.model.ClienteResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.List;

@Component
public class ClientApiDelegateImp implements ClienteApiDelegate {

    @Autowired
    ClientService clientService;

    @Override
    public ResponseEntity<List<ClienteResponse>> listClientes() {
        return ResponseEntity.ok(clientService.listClientes());
    }

    @Override
    public ResponseEntity<ClienteResponse> registerCliente(ClienteRequest clienteRequest) {
        return ResponseEntity.ok(clientService.registerCliente(clienteRequest));
    }



}
